let name;
let age;

name = "ghoul";

age = 10;

console.log(typeof mame,typeof age)